package com.example.moviedb.helper;

public class Const {

    public static final String API_KEY = "b2e1125143f5a22f6ef48a5542bd4bb3";
    public static final String BASE_URL = "https://api.themoviedb.org/3/";
    public static final String IMG_URL = "https://image.tmdb.org/t/p/original/";

}
